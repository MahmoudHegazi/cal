<?php


require('db_connection.php');


function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
if(isset($_GET['id']) && isset($_GET['date'])) {
	
	$secure_day_id = test_input($_GET['id']);
	$secure_day_date = test_input($_GET['date']);

	
?>
<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
* {box-sizing: border-box}

/* Full-width input fields */
input[type=text], [type=date], textarea {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus{
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
input[type=submit]{
  background-color: green !important;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 50%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
  background-color: red !important;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 50%;
  opacity: 0.9;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
  padding: 16px;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}
</style>
</head>
<body>  

<?php
// define variables and set to empty values
$nameErr = $emailErr = $birthErr = $surenameErr = "";
$name = $email = $birth = $comment = $surename = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    // check if name only contains letters and whitespace
    if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
    }
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
    }
  }
    
  if (empty($_POST["surename"])) {
    $surename = "";
  } else {
    $surename = test_input($_POST["surename"]);
    // check if URL address syntax is valid (this regular expression also allows dashes in the URL)
    if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i",$surename)) {
      $surenameErr = "Invalid URL";
    }
  }

  if (empty($_POST["comment"])) {
    $comment = "";
  } else {
    $comment = test_input($_POST["comment"]);
  }

  if (empty($_POST["birth"])) {
    $birthErr = "birth date is required";
  } else {
    $birth = test_input($_POST["birth"]);
  }
    
	//mysqli_query($conn,"SELECT COUNT(used) as a FROM days WHERE used = 1");
	

	


$the_sql = "SELECT used FROM days WHERE used=1";
$result = $conn->query($the_sql);
// if the number of rows of the used days > 14 redirect to the index 
if ($result->num_rows > 14) {
	
  header('Location: index.php?messageer=Your Have Reached Max Reservations ' . $result->num_rows) ;
  
} else {	
	
	
  	mysqli_query($conn,"UPDATE days SET used = 1, user_name = '$name', user_surname = '$surename' , user_mail = '$email', user_birth = '$birth', user_comment = '$comment' WHERE id = $secure_day_id");
	$message = "New Reservation Added: " . $secure_day_date;
    header( 'Location: index.php?message=' . $message ) ;

}

}
?>


<form method="post" action="<?php $prm = '?id=' . $secure_day_id	 . '&date=' . $secure_day_date; echo htmlspecialchars($_SERVER["PHP_SELF"]) . $prm;?>">  
  <div class="container">
	<p>You Are Going to Add new an appointment on date: <?php echo $secure_day_date; ?></p>
    <p>Please fill in this form to create an account.</p>
    <hr>

  <label for="name"><b>Name: </b></label>
  <input type="text" name="name" value="<?php echo $name;?>" required>
  <span class="error"><?php echo $nameErr;?></span><br /><br />

  <label for="surname"><b>Surname: </b></label>
  <input type="text" name="surename" value="<?php echo $surename;?>">
  <span class="error"><?php echo $surenameErr;?></span><br /><br />

  <label for="email"><b>E-mail: </b></label>
  <input type="text" name="email" value="<?php echo $email;?>">
  <span class="error"><?php echo $emailErr;?></span><br /><br />

  <label for="birth"><b>Date of birth(dd/mm/yyyy): </b></label>
   <input type="date" name="birth" value="<?php echo $birth;?>">
  <span class="error"><?php echo $birthErr;?></span><br /><br />

  <label for="comment"><b>Comment: </b></label>
  <textarea name="comment" rows="5" cols="40"><?php echo $comment;?></textarea>
  <br><br>
   

    <div class="clearfix">
      <input class="cancelbtn" type="submit" name="submit" value="Submit">  
      <a href="index.php"><input class="cancelbtn" type="button" name="cancel" value="Back"></a>

    </div>
  </div>
</form>



</body>
</html>
<?php
	// mysqli_query($conn,"UPDATE days SET used = 1 WHERE id = $secure_day_id");
	//$message = "New Reservation Added: " . $secure_day_date;
	//header( 'Location: index.php?message=' . $message ) ;
    //echo $secure_day_id;
   
   
   
}




<!DOCTYPE html>
<html>
<head>
<style>
table {
  width:100%;
}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 15px;
  text-align: left;
}
#t01 tr:nth-child(even) {
  background-color: #eee;
}
#t01 tr:nth-child(odd) {
 background-color: #fff;
}
#t01 th {
  background-color: lightgreen;
  color: black;
}

.navbar {
  overflow: hidden;
  background-color: #333;
  position: block;
  top: 0;
  width: 100%;
}

.navbar a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.navbar a:hover {
  background: #ddd;
  color: black;
}

.main {
  padding: 16px;
  margin-bottom: 30px;
  height: 1500px; /* Used in this example to enable scrolling */
}


/* notifications */

.alert {
  padding: 20px;
  background-color: #f44336;
  color: white;
  opacity: 1;
  transition: opacity 0.6s;
  margin-bottom: 15px;
}

.alert.success {background-color: #4CAF50;}
.alert.info {background-color: #2196F3;}
.alert.warning {background-color: #ff9800;}

.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.closebtn:hover {
  color: black;
}
</style>
</head>
<body>
<div class="navbar">
  <a href="<?php echo getcwd(); ?>">Home</a>
  <a href="<?php echo $_SERVER['REQUEST_URI']; ?>">List</a>
</div>


<div id="notifications">
<?php
if(isset($_GET['message'])) {
	//echo $_GET['message'];
	?>
	<div class="alert success">
  <span class="closebtn">&times;</span>  
  <strong>Notification!</strong> <?php echo $_GET['message']; ?>
</div>
	<?php
}
?>
</div>



<h2>All Reservations</h2>


<table id="t01">
  <tr>
    <th>Name</th>
    <th>Email</th>
    <th>Date</th>
    <th>Options</th>
  </tr>

<?php
require('db_connection.php');

$sql = "SELECT id, time_stamp, user_name, user_mail FROM days WHERE used = 1";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    $output = '';
    while($row = $result->fetch_assoc()) {
?>
  <tr>
    <td><?php echo $row['user_name']; ?></td>

 
    <td><?php echo $row['user_mail']; ?></td>


    <td><?php echo $row['time_stamp']; ?></td>

    <td><a href="details.php?id=<?php echo $row['id']; ?> ">View</a> <a style="padding-left:10px;" href="clean.php?id=<?php echo $row['id']; ?> ">remove</a></td>
 <tr>
<?php
}}
?>

</table>


<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>
</body>
</html>



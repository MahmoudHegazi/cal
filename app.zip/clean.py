<?php

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


if(isset($_GET['id']) ){

$the_id = test_input($_GET['id']);
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "caldb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}else {
	$result = 'full';
}

mysqli_query($conn,"UPDATE days SET used = 1 WHERE id = $the_id");


}
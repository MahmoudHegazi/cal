<?php

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


if(isset($_GET['id']) ){

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "caldb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$the_id = test_input($_GET['id']);
mysqli_query($conn,"UPDATE days SET used = 0 WHERE id = $the_id");
$message = 'Sucessfully Removed The Reservation for day id: ' . $the_id;
header( 'Location: list.php?message=' . $message );

}
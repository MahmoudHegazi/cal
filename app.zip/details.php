<?php
if(isset($_GET['id']) ){

$the_id = $_GET['id'];
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "caldb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}else {
	$result = 'full';
}



$sql = "SELECT user_name, user_surname, user_mail, user_comment, time_stamp, day_name, month_name, user_birth FROM days WHERE id = '$the_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {

     $name = $row['user_name'];
     $surename = $row['user_surname'];
     $mail = $row['user_mail'];
     $comment = $row['user_comment'];
     $time_stamp = $row['time_stamp'];
     $day_name = $row['day_name'];
     $month_name = $row['month_name'];
     $birth = $row['user_birth'];

if ($name == 'Null') {
   $name = 'No Data';
}

if ($surename == 'Null') {
   $surename = 'No Data';
}


if ($mail == 'Null') {
   $mail = 'No Data';
}



if ($birth == 'Null') {
   $birth = 'No Data';
}


if ($comment == 'Null') {
   $comment = '';
}



}

}

?>





<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 50%;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.title {
  color: grey;
  font-size: 18px;
}

button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

a {
  text-decoration: none;
  font-size: 22px;
  color: black;
}

button:hover, a:hover {
  opacity: 0.7;
}

.navbar {
  overflow: hidden;
  background-color: #333;
  position: block;
  top: 0;
  width: 100%;
}

.navbar a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.navbar a:hover {
  background: #ddd;
  color: black;
}

.main {
  padding: 16px;
  margin-bottom: 30px;
  height: 1500px; /* Used in this example to enable scrolling */
}
</style>
</head>
<body>

<div class="navbar">
  <a href="index.php">Home</a>
  <a href="list.php">List</a>
</div>
<br /><br />



<div class="card">
<span>Day Name: <?php echo $day_name; ?></span> 
<span style="margin-left:10%;">Month Name: <?php echo $month_name; ?>  </span>
<span style="margin-left:10%;">Full Date: <?php echo $time_stamp; ?> </span> 
</div>
<div class="card">
  <img src="https://cdn0.iconfinder.com/data/icons/logistics-icons-set-cartoon-style/512/a1189-512.png" alt="John" style="width:100%;height:300px;">
  <h1>Name: <?php echo $name; ?></h1>
  <p class="title">Surname: <?php echo $surename; ?></p>
  <p>Email: <?php echo $mail; ?></p>
  <p>Birth Date: <?php echo $birth; ?></p>
  <p>Comment: <?php echo $comment; ?></p>
  <p><a href="list.php"><button>Back</button></a></p>
</div>

</body>
</html>







<?php
}









?>
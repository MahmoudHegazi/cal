<?php
if(isset($_GET['year']) ){


$months = [];

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "caldb";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}else {
	$result = 'full';
}

$make_range = range(1, 12);

foreach( $make_range as $month_num) {
$sql = "SELECT * FROM days WHERE year = " . $_GET['year'] . " AND month = " . $month_num;
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    $output = '';
    while($row = $result->fetch_assoc()) {
		if ($row["used"]) {
        $output = '<a href="reservation.php?id=' . $row["id"] . '&date=' . $row["time_stamp"] . '"><li class="' . $row["day_class"] .' active" data-year="' . $row["year"] . 
		'" data-month="' . $row["month"] . '" data-date="' . $row["time_stamp"] . '" data-used="' .
		$row["used"] . '" data-day-name="'. $row["day_name"] .'" data-month-name="' .
		$row["month_name"]. '" data-day-short="' . $row["day_short_name"] . '" data-month-short="'. $row["month_short_name"] .'" id="day' . $row["id"] . '" title="' .
        $row["user_name"] . ',  Mail: ' . $row["user_mail"] . '">'.$row["day"].'</li></a>';
        array_push($months, $output);
		//echo $output;
		} else {
        $output = '<a href="reservation.php?id=' . $row["id"] . '&date=' . $row["time_stamp"] . '"><li class="' . $row["day_class"] .'" data-year="' . $row["year"] . 
		'" data-month="' . $row["month"] . '" data-date="' . $row["time_stamp"] . '" data-used="' .
		$row["used"] . '" data-day-name="'. $row["day_name"] .'" data-month-name="' .
		$row["month_name"]. '" data-day-short="' . $row["day_short_name"] . '" data-month-short="'. $row["month_short_name"] .'" id="day' . $row["id"] . '">'.$row["day"].'</li></a>';
        //echo $output;			
		array_push($months, $output);
		}
    } 

    array_push($months, '|');
} else {
    echo "0 results";
}

}

}

    for ($i=0; $i<count($months); $i++){
        echo $months[$i];
    }
//print_r($months);







?>